import os

os.system("pip3 install pyrogram")
os.system("pip3 install tgcrypto")
os.system("pip3 install colorama")
os.system("pip3 install lolpython")
os.system("pip3 install requests")
os.system("pip install pyfiglet")

print("|✓| Installation Done")